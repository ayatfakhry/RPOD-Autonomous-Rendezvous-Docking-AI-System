"""
ekf_sensor_fusion.py — Extended Kalman Filter for GNSS/IMU/LiDAR Fusion
========================================================================
6-DoF EKF with Clohessy-Wiltshire dynamics model.
Supports adaptive noise tuning and sensor fault detection.
"""

import numpy as np
from typing import Optional, Tuple

MU      = 3.986004418e14
RE      = 6.3781e6
ALT     = 408e3
R_ORBIT = RE + ALT
N_MOT   = np.sqrt(MU / R_ORBIT**3)


class SensorFusionEKF:
    """
    6-DoF EKF fusing GNSS position, LiDAR position, and IMU acceleration.

    State: x = [px, py, pz, vx, vy, vz]  (CW relative frame)
    Meas:  z_gps   = [px, py, pz] + noise(σ_gps)
           z_lidar = [px, py, pz] + noise(σ_lidar)
           z_imu   = [ax, ay, az] + bias + noise

    Process noise Q is adaptive: increases on fault detection.
    """

    def __init__(
        self,
        gnss_std:  float = 3.0,
        lidar_std: float = 0.15,
        imu_std:   float = 1e-4,
        lidar_range: float = 500.0,
    ):
        self.gnss_std   = gnss_std
        self.lidar_std  = lidar_std
        self.imu_std    = imu_std
        self.lidar_range= lidar_range

        self.x = np.zeros(6)          # state estimate
        self.P = np.eye(6) * 1000.0   # covariance
        self._init_noise()

        self.innovation_history = []
        self.fault_detected     = False
        self.n_updates          = 0

    def _init_noise(self):
        """Set process and measurement noise matrices."""
        q_pos = 0.05
        q_vel = 0.005
        self.Q = np.diag([q_pos, q_pos, q_pos * 0.5, q_vel, q_vel, q_vel * 0.3])

        self.R_gnss  = np.eye(3) * self.gnss_std**2
        self.R_lidar = np.eye(3) * self.lidar_std**2

    def reset(self, x0: Optional[np.ndarray] = None):
        self.x = x0.copy() if x0 is not None else np.zeros(6)
        self.P = np.eye(6) * 1000.0
        self.innovation_history = []
        self.fault_detected = False
        self.n_updates = 0

    # ── CW state-transition matrix ────────────────────────────────────────────
    def _F(self, dt: float) -> np.ndarray:
        n = N_MOT
        c, s = np.cos(n*dt), np.sin(n*dt)
        return np.array([
            [4-3*c,  0, 0,  s/n,      2*(1-c)/n, 0   ],
            [6*(s-n*dt),1,0,-2*(c-1)/n,(4*s/n-3*dt),0 ],
            [0,      0, c,  0,         0,         s/n ],
            [3*n*s,  0, 0,  c,         2*s,       0   ],
            [-6*n*(1-c),0,0,-2*s,      4*c-3,     0   ],
            [0,      0,-n*s,0,         0,         c   ],
        ])

    # ── Predict ───────────────────────────────────────────────────────────────
    def predict(self, dt: float, accel: Optional[np.ndarray] = None):
        F  = self._F(dt)
        B  = np.zeros((6, 3))
        B[0, 0] = 0.5 * dt**2
        B[1, 1] = 0.5 * dt**2
        B[2, 2] = 0.5 * dt**2
        B[3, 0] = dt
        B[4, 1] = dt
        B[5, 2] = dt

        a = accel if accel is not None else np.zeros(3)
        self.x = F @ self.x + B @ a

        Q_adaptive = self.Q * (5.0 if self.fault_detected else 1.0)
        self.P = F @ self.P @ F.T + Q_adaptive

    # ── Position update (GNSS or LiDAR) ──────────────────────────────────────
    def update_position(
        self, z: np.ndarray, sensor: str = "gnss"
    ) -> Tuple[np.ndarray, float]:
        H = np.zeros((3, 6))
        H[0, 0] = H[1, 1] = H[2, 2] = 1.0

        R = self.R_lidar if sensor == "lidar" else self.R_gnss

        innov = z - H @ self.x
        S     = H @ self.P @ H.T + R
        K     = self.P @ H.T @ np.linalg.inv(S)

        self.x = self.x + K @ innov
        self.P = (np.eye(6) - K @ H) @ self.P

        innov_norm = float(np.linalg.norm(innov))
        self.innovation_history.append(innov_norm)
        if len(self.innovation_history) > 50:
            self.innovation_history.pop(0)

        # Chi-squared fault detection (threshold = 3-sigma)
        chi2 = float(innov @ np.linalg.inv(S) @ innov)
        self.fault_detected = chi2 > 14.07   # χ²(3, 0.003)
        self.n_updates += 1

        return self.x.copy(), innov_norm

    # ── Properties ────────────────────────────────────────────────────────────
    @property
    def position(self) -> np.ndarray:
        return self.x[:3].copy()

    @property
    def velocity(self) -> np.ndarray:
        return self.x[3:].copy()

    @property
    def position_uncertainty(self) -> float:
        return float(np.sqrt(self.P[0,0] + self.P[1,1] + self.P[2,2]))

    @property
    def mean_innovation(self) -> float:
        if not self.innovation_history:
            return 0.0
        return float(np.mean(self.innovation_history))
