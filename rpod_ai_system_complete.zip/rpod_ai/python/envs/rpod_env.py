"""
rpod_env.py — RPOD Gymnasium Environment
=========================================
Autonomous Rendezvous, Proximity Operations & Docking (RPOD) System
Clohessy-Wiltshire relative orbital mechanics with 6-DoF state space.

Physics Reference:
  Clohessy, W.H. & Wiltshire, R.S. (1960). Terminal Guidance System for
  Satellite Rendezvous. Journal of the Aerospace Sciences, 27(9), 653–658.

State  : [x, y, z, vx, vy, vz]   (CW frame, metres / m·s⁻¹)
Action : [ax, ay, az]              (thrust acceleration, m·s⁻²)
"""

import numpy as np
import gymnasium as gym
from gymnasium import spaces
from dataclasses import dataclass, field
from typing import Optional, Tuple, Dict, Any


# ── Physical constants ────────────────────────────────────────────────────────
MU       = 3.986004418e14   # m³/s²  Earth gravitational parameter
RE       = 6.3781e6         # m      Earth equatorial radius
ALT      = 408e3            # m      ISS orbital altitude
R_ORBIT  = RE + ALT         # m      Orbital radius
N_MOTION = np.sqrt(MU / R_ORBIT**3)   # rad/s  Mean motion ≈ 0.001136 rad/s
V_CIRC   = np.sqrt(MU / R_ORBIT)      # m/s    Circular velocity ≈ 7666 m/s

# ── Mission phase thresholds (metres) ────────────────────────────────────────
PHASE_THRESHOLDS = {
    "FAR_FIELD"       : (500.0, np.inf),
    "MID_RANGE"       : (150.0, 500.0),
    "PROXIMITY_OPS"   : (30.0,  150.0),
    "STATIONKEEPING"  : (5.0,   30.0),
    "DOCKING_APPROACH": (0.5,   5.0),
    "CAPTURE"         : (0.0,   0.5),
}


@dataclass
class RPODConfig:
    """Simulation configuration — all units SI."""
    # Timing
    dt: float = 0.4                   # timestep [s]
    max_steps: int = 4000             # episode limit

    # Initial conditions
    init_range_min: float = 1500.0    # m
    init_range_max: float = 2500.0    # m
    init_vel_std:   float = 0.05      # m/s  relative velocity noise

    # Thrust limits (RCS thruster model)
    max_thrust: float = 0.003         # m/s²  ~3 mN/kg specific force
    min_thrust: float = 0.0           # m/s²

    # Docking criteria
    dock_position_tol: float = 0.30   # m
    dock_velocity_tol: float = 0.05   # m/s

    # Fuel model
    isp: float = 220.0                # s   (hydrazine monoprop)
    g0:  float = 9.80665              # m/s²
    initial_mass: float = 500.0       # kg  chaser wet mass

    # Sensor noise (1-sigma)
    gnss_noise_std:  float = 3.0      # m   position (far field)
    lidar_noise_std: float = 0.15     # m   position (<500 m)
    imu_noise_std:   float = 1e-5     # m/s² acceleration bias/noise
    gnss_fault_prob: float = 0.005    # probability of GNSS dropout/step
    lidar_range:     float = 500.0    # m   LiDAR activation range

    # Debris field
    n_debris: int = 8
    debris_hazard_radius: float = 5.0  # m  collision hazard

    # Reward shaping weights
    w_distance:  float = -0.5
    w_velocity:  float = -0.3
    w_fuel:      float = -0.2
    w_alignment: float =  0.4
    w_dock:      float = 500.0
    w_crash:     float = -200.0
    w_debris:    float = -50.0
    w_timeout:   float = -100.0
    w_progress:  float =  1.0         # shaping: reward for range reduction


@dataclass
class RPODState:
    """Full simulation state."""
    # CW relative position & velocity
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    vx: float = 0.0
    vy: float = 0.0
    vz: float = 0.0

    # Fuel / mass
    mass: float = 500.0
    fuel_mass: float = 100.0          # kg propellant

    # Debris positions
    debris_positions: np.ndarray = field(default_factory=lambda: np.zeros((8, 3)))
    debris_velocities: np.ndarray = field(default_factory=lambda: np.zeros((8, 3)))

    # Fault flags
    gnss_fault: bool = False
    imu_fault: bool = False

    # Step counter
    step: int = 0
    prev_range: float = 2000.0


class RPODEnvironment(gym.Env):
    """
    RPOD Gymnasium Environment
    ==========================
    6-DoF Clohessy-Wiltshire rendezvous environment with:
      • Realistic sensor noise (GNSS, LiDAR, IMU)
      • Random fault injection (GNSS dropout, IMU drift)
      • Dynamic debris field with avoidance penalty
      • Rocket equation fuel model (Tsiolkovsky)
      • Dense reward shaping for stable RL training
      • Phase-aware termination and logging

    Observation space (18-dim):
      [x, y, z,                     — relative position (normalised)
       vx, vy, vz,                  — relative velocity (normalised)
       ax_prev, ay_prev, az_prev,   — previous action (normalised)
       fuel_fraction,               — remaining propellant ratio
       gnss_ok, lidar_ok,           — sensor status (binary)
       phase_onehot (6-dim)]        — current mission phase (one-hot)

    Action space (3-dim continuous):
      [ax, ay, az] ∈ [-max_thrust, max_thrust]
    """

    metadata = {"render_modes": ["human", "rgb_array"]}

    def __init__(self, config: Optional[RPODConfig] = None, render_mode: Optional[str] = None):
        super().__init__()
        self.cfg = config or RPODConfig()
        self.render_mode = render_mode
        self._state: Optional[RPODState] = None
        self._prev_action = np.zeros(3)
        self._episode_rewards: list = []
        self._episode_log: list = []

        # ── Observation space ─────────────────────────────────────────────
        obs_dim = 3 + 3 + 3 + 1 + 2 + 6   # = 18
        self.observation_space = spaces.Box(
            low=-np.ones(obs_dim, dtype=np.float32) * 10,
            high=np.ones(obs_dim, dtype=np.float32) * 10,
            dtype=np.float32,
        )

        # ── Action space ──────────────────────────────────────────────────
        self.action_space = spaces.Box(
            low=-self.cfg.max_thrust * np.ones(3, dtype=np.float32),
            high=self.cfg.max_thrust * np.ones(3, dtype=np.float32),
            dtype=np.float32,
        )

        # Normalisation constants
        self._pos_scale = 2500.0     # m
        self._vel_scale = 2.0        # m/s
        self._acc_scale = self.cfg.max_thrust

    # ── Gymnasium API ─────────────────────────────────────────────────────────

    def reset(
        self,
        seed: Optional[int] = None,
        options: Optional[Dict] = None,
    ) -> Tuple[np.ndarray, Dict]:
        super().reset(seed=seed)
        cfg = self.cfg

        # Randomised initial conditions
        r0 = self.np_random.uniform(cfg.init_range_min, cfg.init_range_max)
        theta0 = self.np_random.uniform(0, 2 * np.pi)
        phi0   = self.np_random.uniform(-np.pi / 6, np.pi / 6)

        x0  =  r0 * np.cos(theta0) * np.cos(phi0)
        y0  =  r0 * np.sin(theta0) * np.cos(phi0)
        z0  =  r0 * np.sin(phi0)
        vx0 = self.np_random.normal(0, cfg.init_vel_std)
        vy0 = self.np_random.normal(0, cfg.init_vel_std)
        vz0 = self.np_random.normal(0, cfg.init_vel_std * 0.3)

        # Debris field (random positions in CW frame)
        dpos = self.np_random.uniform(-1500, 1500, size=(cfg.n_debris, 3))
        dvel = self.np_random.uniform(-0.2, 0.2, size=(cfg.n_debris, 3))
        dvel[:, 2] *= 0.3

        self._state = RPODState(
            x=x0, y=y0, z=z0, vx=vx0, vy=vy0, vz=vz0,
            mass=cfg.initial_mass,
            fuel_mass=cfg.initial_mass * 0.25,   # 25% propellant fraction
            debris_positions=dpos,
            debris_velocities=dvel,
            prev_range=r0,
        )
        self._prev_action = np.zeros(3)
        self._episode_rewards = []
        self._episode_log = []

        obs = self._get_obs()
        info = self._get_info()
        return obs, info

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, bool, Dict]:
        assert self._state is not None, "Call reset() before step()."
        cfg = self.cfg
        s = self._state

        # ── Clamp action ──────────────────────────────────────────────────
        action = np.clip(action, -cfg.max_thrust, cfg.max_thrust)

        # ── Fault injection ───────────────────────────────────────────────
        s.gnss_fault = self.np_random.random() < cfg.gnss_fault_prob
        s.imu_fault  = self.np_random.random() < cfg.gnss_fault_prob * 0.4

        # IMU noise on applied thrust
        imu_noise = self.np_random.normal(0, cfg.imu_noise_std, size=3)
        applied_thrust = action + (imu_noise if not s.imu_fault else imu_noise * 10)

        # ── CW propagation (3D) ───────────────────────────────────────────
        dt, n = cfg.dt, N_MOTION
        x,y,z,vx,vy,vz = s.x, s.y, s.z, s.vx, s.vy, s.vz
        ax, ay, az = applied_thrust

        c, sv = np.cos(n*dt), np.sin(n*dt)
        s.x  = (4-3*c)*x + sv/n*vx + 2*(1-c)/n*vy + 0.5*ax*dt**2
        s.y  = 6*(sv-n*dt)*x + y - 2*(c-1)/n*vx + (4*sv/n-3*dt)*vy + 0.5*ay*dt**2
        s.z  =  z*c + vz/n*sv + 0.5*az*dt**2
        s.vx =  3*n*sv*x + c*vx + 2*sv*vy + ax*dt
        s.vy = -6*n*(1-c)*x - 2*sv*vx + (4*c-3)*vy + ay*dt
        s.vz = -n*z*sv + vz*c + az*dt

        # ── Fuel model (Tsiolkovsky) ──────────────────────────────────────
        thrust_mag = np.linalg.norm(applied_thrust)
        if thrust_mag > 1e-9 and s.fuel_mass > 0:
            dm = thrust_mag * s.mass * dt / (cfg.isp * cfg.g0)
            dm = min(dm, s.fuel_mass)
            s.fuel_mass -= dm
            s.mass -= dm

        # ── Propagate debris ──────────────────────────────────────────────
        s.debris_positions += s.debris_velocities * dt

        # ── Range & phase ─────────────────────────────────────────────────
        pos = np.array([s.x, s.y, s.z])
        vel = np.array([s.vx, s.vy, s.vz])
        dist   = float(np.linalg.norm(pos))
        speed  = float(np.linalg.norm(vel))
        phase  = self._get_phase(dist)

        # ── Debris proximity ──────────────────────────────────────────────
        debris_dists = np.linalg.norm(s.debris_positions - pos, axis=1)
        closest_debris = float(debris_dists.min())

        # ── Reward shaping ────────────────────────────────────────────────
        reward = self._compute_reward(
            dist, speed, thrust_mag, s.prev_range,
            closest_debris, s.fuel_mass, phase,
        )
        s.prev_range = dist
        self._prev_action = action
        s.step += 1

        # ── Termination conditions ────────────────────────────────────────
        docked   = dist < cfg.dock_position_tol and speed < cfg.dock_velocity_tol
        crashed  = dist > 4000.0
        fuel_out = s.fuel_mass <= 0.01
        timeout  = s.step >= cfg.max_steps
        debris_hit = closest_debris < cfg.debris_hazard_radius

        terminated = docked or crashed or debris_hit
        truncated  = timeout or fuel_out

        if docked:      reward += cfg.w_dock
        if crashed:     reward += cfg.w_crash
        if debris_hit:  reward += cfg.w_debris
        if timeout:     reward += cfg.w_timeout

        self._episode_rewards.append(reward)
        self._episode_log.append({
            "step": s.step, "dist": dist, "speed": speed,
            "fuel": s.fuel_mass, "phase": phase, "reward": reward,
        })

        obs  = self._get_obs()
        info = self._get_info(
            dist=dist, speed=speed, phase=phase,
            docked=docked, fuel=s.fuel_mass,
            closest_debris=closest_debris,
        )
        return obs, float(reward), terminated, truncated, info

    def render(self):
        """Simple ASCII telemetry for human render mode."""
        if self.render_mode == "human" and self._state is not None:
            s = self._state
            dist = np.sqrt(s.x**2 + s.y**2 + s.z**2)
            phase = self._get_phase(dist)
            print(
                f"[T+{s.step*self.cfg.dt:.1f}s] "
                f"Range:{dist:8.2f}m  "
                f"Speed:{np.sqrt(s.vx**2+s.vy**2+s.vz**2):.4f}m/s  "
                f"Fuel:{s.fuel_mass:.2f}kg  "
                f"Phase:{phase}"
            )

    def close(self):
        pass

    # ── Private helpers ───────────────────────────────────────────────────────

    def _cw_stm(self, dt: float) -> np.ndarray:
        """Return 6×6 CW state-transition matrix."""
        n = N_MOTION
        c, sv = np.cos(n*dt), np.sin(n*dt)
        return np.array([
            [4-3*c,  0, 0,  sv/n,     2*(1-c)/n, 0    ],
            [6*(sv-n*dt),1,0, -2*(c-1)/n,(4*sv/n-3*dt),0],
            [0,      0, c,  0,         0,         sv/n ],
            [3*n*sv, 0, 0,  c,         2*sv,      0    ],
            [-6*n*(1-c),0,0,-2*sv,     4*c-3,     0    ],
            [0,      0,-n*sv,0,        0,         c    ],
        ])

    def _get_obs(self) -> np.ndarray:
        s = self._state
        cfg = self.cfg
        dist = np.sqrt(s.x**2 + s.y**2 + s.z**2)

        # Position measurement (GNSS or LiDAR)
        if dist < cfg.lidar_range:
            noise_std = cfg.lidar_noise_std
            lidar_ok  = 1.0
        else:
            noise_std = cfg.gnss_noise_std * (2.0 if s.gnss_fault else 1.0)
            lidar_ok  = 0.0
        gnss_ok = 0.0 if s.gnss_fault else 1.0

        pos_meas = np.array([s.x, s.y, s.z]) + self.np_random.normal(0, noise_std, 3)
        vel_meas = np.array([s.vx, s.vy, s.vz]) + self.np_random.normal(0, 0.02, 3)

        # Mission phase one-hot
        phase = self._get_phase(dist)
        phase_names = list(PHASE_THRESHOLDS.keys())
        phase_onehot = np.zeros(6, dtype=np.float32)
        if phase in phase_names:
            phase_onehot[phase_names.index(phase)] = 1.0

        obs = np.concatenate([
            pos_meas / self._pos_scale,
            vel_meas / self._vel_scale,
            self._prev_action / self._acc_scale,
            [s.fuel_mass / (cfg.initial_mass * 0.25)],
            [gnss_ok, lidar_ok],
            phase_onehot,
        ]).astype(np.float32)

        return np.clip(obs, -10.0, 10.0)

    def _get_info(self, **kwargs) -> Dict[str, Any]:
        s = self._state
        dist = kwargs.get("dist", np.sqrt(s.x**2+s.y**2+s.z**2))
        return {
            "dist":    dist,
            "speed":   kwargs.get("speed", np.sqrt(s.vx**2+s.vy**2+s.vz**2)),
            "fuel":    kwargs.get("fuel", s.fuel_mass),
            "phase":   kwargs.get("phase", self._get_phase(dist)),
            "docked":  kwargs.get("docked", False),
            "closest_debris": kwargs.get("closest_debris", 9999.0),
            "episode_reward": sum(self._episode_rewards),
            "step":    s.step,
        }

    def _get_phase(self, dist: float) -> str:
        for phase, (lo, hi) in PHASE_THRESHOLDS.items():
            if lo <= dist < hi:
                return phase
        return "CAPTURE"

    def _compute_reward(
        self, dist, speed, thrust_mag, prev_dist,
        closest_debris, fuel_mass, phase
    ) -> float:
        cfg = self.cfg

        # Progress reward (potential-based shaping)
        progress = (prev_dist - dist) * cfg.w_progress

        # Distance penalty (tanh-scaled to avoid reward hacking)
        dist_penalty = cfg.w_distance * np.tanh(dist / 100.0)

        # Velocity penalty (penalise high relative speed, especially when close)
        vel_penalty = cfg.w_velocity * np.tanh(speed * 5.0)

        # Fuel penalty (proportional to thrust magnitude)
        fuel_penalty = cfg.w_fuel * thrust_mag / cfg.max_thrust

        # Alignment reward (penalise out-of-plane motion)
        alignment = cfg.w_alignment * (1.0 - abs(self._state.z) / max(dist, 1.0))

        # Debris avoidance
        if closest_debris < 50.0:
            debris_pen = cfg.w_debris * np.exp(-closest_debris / 20.0) * 0.1
        else:
            debris_pen = 0.0

        # Phase bonus (incremental milestone rewards)
        phase_bonus = 0.0
        if phase == "PROXIMITY_OPS"   : phase_bonus = 0.05
        elif phase == "STATIONKEEPING" : phase_bonus = 0.15
        elif phase == "DOCKING_APPROACH": phase_bonus = 0.50
        elif phase == "CAPTURE"        : phase_bonus = 2.0

        return (
            progress + dist_penalty + vel_penalty +
            fuel_penalty + alignment + debris_pen + phase_bonus
        )

    # ── Utilities ─────────────────────────────────────────────────────────────

    def get_episode_stats(self) -> Dict[str, float]:
        """Return episode-level statistics for logging."""
        if not self._episode_log:
            return {}
        dists  = [e["dist"] for e in self._episode_log]
        fuels  = [e["fuel"] for e in self._episode_log]
        return {
            "ep_total_reward": sum(self._episode_rewards),
            "ep_final_range":  dists[-1],
            "ep_min_range":    min(dists),
            "ep_fuel_used":    fuels[0] - fuels[-1],
            "ep_steps":        len(self._episode_log),
            "ep_docked":       float(dists[-1] < self.cfg.dock_position_tol),
        }
