"""
train.py — RPOD AI Training Pipeline
=====================================
Trains DQN and PPO agents on the RPOD environment with:
  • Structured logging (TensorBoard + CSV)
  • Periodic evaluation episodes
  • Checkpoint saving / resuming
  • Comparison between AI and classical GNSS-IMU baseline
  • Command-line interface

Usage:
    python train.py --algo ppo --episodes 5000 --eval-every 100
    python train.py --algo dqn --episodes 10000 --resume checkpoints/dqn_best.pt
    python train.py --compare  # run comparison benchmark
"""

import argparse
import csv
import logging
import os
import sys
import time
from pathlib import Path
from typing import Optional

import numpy as np

# Optional: TensorBoard
try:
    from torch.utils.tensorboard import SummaryWriter
    HAS_TB = True
except ImportError:
    HAS_TB = False

# ── Path setup ────────────────────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))
from envs.rpod_env import RPODEnvironment, RPODConfig
from agents.dqn_agent import DQNAgent
from agents.ppo_agent import PPOAgent
from utils.ekf_sensor_fusion import SensorFusionEKF
from evaluation.evaluator import Evaluator, ClassicalBaseline

# ── Logging ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("train")


# ── Helpers ───────────────────────────────────────────────────────────────────

def moving_average(arr, window=20):
    if len(arr) < window:
        return [np.mean(arr)]
    return [np.mean(arr[max(0, i-window):i+1]) for i in range(len(arr))]


class MetricsLogger:
    """Writes episode metrics to CSV and (optionally) TensorBoard."""

    def __init__(self, log_dir: str, algo: str):
        os.makedirs(log_dir, exist_ok=True)
        self.csv_path = os.path.join(log_dir, f"{algo}_metrics.csv")
        self._csv_file = open(self.csv_path, "w", newline="")
        self._writer = csv.writer(self._csv_file)
        self._writer.writerow([
            "episode", "total_reward", "final_range_m", "min_range_m",
            "fuel_used_kg", "steps", "docked", "duration_s",
        ])
        self.tb = SummaryWriter(log_dir) if HAS_TB else None
        logger.info(f"CSV log → {self.csv_path}")

    def log_episode(self, ep: int, stats: dict):
        self._writer.writerow([
            ep,
            f"{stats.get('ep_total_reward', 0):.2f}",
            f"{stats.get('ep_final_range', 0):.4f}",
            f"{stats.get('ep_min_range', 0):.4f}",
            f"{stats.get('ep_fuel_used', 0):.4f}",
            stats.get("ep_steps", 0),
            int(stats.get("ep_docked", 0)),
            f"{stats.get('duration', 0):.3f}",
        ])
        self._csv_file.flush()

        if self.tb:
            for k, v in stats.items():
                try:
                    self.tb.add_scalar(f"episode/{k}", v, ep)
                except Exception:
                    pass

    def log_training(self, step: int, metrics: dict):
        if self.tb:
            for k, v in metrics.items():
                try:
                    self.tb.add_scalar(f"train/{k}", v, step)
                except Exception:
                    pass

    def close(self):
        self._csv_file.close()
        if self.tb:
            self.tb.close()


# ── PPO Training Loop ─────────────────────────────────────────────────────────

def train_ppo(
    n_episodes: int,
    eval_every: int,
    ckpt_dir: str,
    resume: Optional[str],
    log_dir: str,
    cfg: RPODConfig,
    seed: int = 42,
) -> dict:
    """Train PPO agent and return final evaluation statistics."""
    env  = RPODEnvironment(config=cfg, render_mode=None)
    eval_env = RPODEnvironment(config=cfg)
    ekf  = SensorFusionEKF()
    agent = PPOAgent(
        obs_dim=env.observation_space.shape[0],
        action_dim=env.action_space.shape[0],
        max_thrust=cfg.max_thrust,
    )
    if resume:
        agent.load(resume)

    mlog   = MetricsLogger(log_dir, "ppo")
    evaluator = Evaluator(eval_env, agent, mode="ppo")
    best_reward = -np.inf
    ep_rewards = []

    logger.info("=" * 60)
    logger.info(f"  Training PPO | Episodes: {n_episodes} | Seed: {seed}")
    logger.info("=" * 60)

    total_steps = 0
    for episode in range(1, n_episodes + 1):
        obs, _ = env.reset(seed=seed + episode)
        ekf.reset()
        ep_reward = 0.0
        t0 = time.time()
        done = False

        while not done:
            action, log_prob, value = agent.act(obs)

            next_obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated

            agent.store(obs, action, reward, done, value, log_prob)

            # Trigger update when buffer full
            if agent.buffer.is_full():
                _, last_val, _ = agent.act(next_obs)
                metrics = agent.update(last_val if not done else 0.0)
                mlog.log_training(total_steps, metrics)

            obs = next_obs
            ep_reward += reward
            total_steps += 1

        agent.end_episode()
        stats = env.get_episode_stats()
        stats["ep_total_reward"] = ep_reward
        stats["duration"] = time.time() - t0
        ep_rewards.append(ep_reward)
        mlog.log_episode(episode, stats)

        # Console log every 10 episodes
        if episode % 10 == 0:
            ma = np.mean(ep_rewards[-20:])
            dock_rate = np.mean([s == 1.0 for s in ep_rewards[-20:] if s > 400]) if len(ep_rewards) >= 20 else 0
            logger.info(
                f"Ep {episode:5d}/{n_episodes} | "
                f"Reward: {ep_reward:8.1f} | MA20: {ma:8.1f} | "
                f"Range: {stats.get('ep_final_range',0):7.2f}m | "
                f"Fuel: {stats.get('ep_fuel_used',0):.2f}kg | "
                f"Steps: {total_steps:,}"
            )

        # Evaluation
        if episode % eval_every == 0:
            eval_stats = evaluator.run(n_episodes=5, deterministic=True)
            logger.info(
                f"  [EVAL] Reward: {eval_stats['mean_reward']:8.1f} ± "
                f"{eval_stats['std_reward']:.1f} | "
                f"Dock rate: {eval_stats['dock_rate']*100:.1f}% | "
                f"Fuel: {eval_stats['mean_fuel_used']:.2f}kg"
            )
            if eval_stats["mean_reward"] > best_reward:
                best_reward = eval_stats["mean_reward"]
                agent.save(os.path.join(ckpt_dir, "ppo_best.pt"))
                logger.info(f"  ✓ New best checkpoint (reward={best_reward:.1f})")

        # Periodic checkpoint
        if episode % 500 == 0:
            agent.save(os.path.join(ckpt_dir, f"ppo_ep{episode}.pt"))

    agent.save(os.path.join(ckpt_dir, "ppo_final.pt"))
    mlog.close()
    logger.info(f"PPO training complete. Best reward: {best_reward:.1f}")
    return {"best_reward": best_reward, "total_steps": total_steps}


# ── DQN Training Loop ─────────────────────────────────────────────────────────

def train_dqn(
    n_episodes: int,
    eval_every: int,
    ckpt_dir: str,
    resume: Optional[str],
    log_dir: str,
    cfg: RPODConfig,
    seed: int = 42,
) -> dict:
    """Train DQN agent and return final evaluation statistics."""
    env      = RPODEnvironment(config=cfg)
    eval_env = RPODEnvironment(config=cfg)
    agent    = DQNAgent(
        obs_dim=env.observation_space.shape[0],
        max_thrust=cfg.max_thrust,
    )
    if resume:
        agent.load(resume)

    mlog      = MetricsLogger(log_dir, "dqn")
    evaluator = Evaluator(eval_env, agent, mode="dqn")
    best_reward = -np.inf
    ep_rewards  = []

    logger.info("=" * 60)
    logger.info(f"  Training DQN | Episodes: {n_episodes} | Seed: {seed}")
    logger.info("=" * 60)

    total_steps = 0
    for episode in range(1, n_episodes + 1):
        obs, _ = env.reset(seed=seed + episode)
        ep_reward = 0.0
        t0 = time.time()
        done = False

        while not done:
            action_vec, action_idx = agent.act(obs)
            next_obs, reward, terminated, truncated, info = env.step(action_vec)
            done = terminated or truncated

            learn_metrics = agent.step(obs, action_idx, reward, next_obs, done)
            if learn_metrics:
                mlog.log_training(total_steps, learn_metrics)

            obs = next_obs
            ep_reward += reward
            total_steps += 1

        agent.end_episode()
        stats = env.get_episode_stats()
        stats["ep_total_reward"] = ep_reward
        stats["duration"] = time.time() - t0
        ep_rewards.append(ep_reward)
        mlog.log_episode(episode, stats)

        if episode % 10 == 0:
            ma = np.mean(ep_rewards[-20:])
            logger.info(
                f"Ep {episode:5d}/{n_episodes} | "
                f"Reward: {ep_reward:8.1f} | MA20: {ma:8.1f} | "
                f"Range: {stats.get('ep_final_range',0):7.2f}m | "
                f"Loss: {agent.mean_loss:.4f} | Steps: {total_steps:,}"
            )

        if episode % eval_every == 0:
            eval_stats = evaluator.run(n_episodes=5, deterministic=True)
            logger.info(
                f"  [EVAL] Reward: {eval_stats['mean_reward']:8.1f} ± "
                f"{eval_stats['std_reward']:.1f} | "
                f"Dock rate: {eval_stats['dock_rate']*100:.1f}%"
            )
            if eval_stats["mean_reward"] > best_reward:
                best_reward = eval_stats["mean_reward"]
                agent.save(os.path.join(ckpt_dir, "dqn_best.pt"))

        if episode % 500 == 0:
            agent.save(os.path.join(ckpt_dir, f"dqn_ep{episode}.pt"))

    agent.save(os.path.join(ckpt_dir, "dqn_final.pt"))
    mlog.close()
    logger.info(f"DQN training complete. Best reward: {best_reward:.1f}")
    return {"best_reward": best_reward, "total_steps": total_steps}


# ── Comparison Benchmark ──────────────────────────────────────────────────────

def run_comparison(cfg: RPODConfig, n_episodes: int = 50):
    """
    Compare AI agents vs classical PD controller baseline.
    Outputs a summary table.
    """
    logger.info("Running performance comparison (AI vs Classical baseline)…")
    env      = RPODEnvironment(config=cfg)
    baseline = ClassicalBaseline(max_thrust=cfg.max_thrust)
    evaluator_b = Evaluator(env, baseline, mode="classical")
    b_stats = evaluator_b.run(n_episodes=n_episodes, deterministic=True)

    print("\n" + "=" * 70)
    print("  RPOD PERFORMANCE COMPARISON: AI vs Classical GNSS-IMU Control")
    print("=" * 70)
    print(f"{'Metric':<30} {'Classical PD':>18} {'PPO (AI)':>14} {'DQN (AI)':>14}")
    print("-" * 70)
    metrics_to_show = [
        ("Mean Episode Reward", "mean_reward"),
        ("Dock Success Rate (%)", "dock_rate"),
        ("Mean Final Range (m)", "mean_final_range"),
        ("Mean Fuel Used (kg)",  "mean_fuel_used"),
        ("Mean Steps to Dock",   "mean_steps"),
    ]
    for label, key in metrics_to_show:
        bval = b_stats.get(key, 0)
        if key == "dock_rate":
            bval = f"{bval*100:.1f}%"
        else:
            bval = f"{bval:.3f}"
        print(f"  {label:<28} {bval:>18}  {'(train first)':>14}  {'(train first)':>14}")
    print("=" * 70)
    print("  Note: Train agents first (--algo ppo / --algo dqn) to populate AI columns.")
    print()


# ── CLI ───────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(
        description="RPOD AI Training — Autonomous Rendezvous & Docking"
    )
    p.add_argument("--algo",       choices=["ppo", "dqn", "both"], default="ppo")
    p.add_argument("--episodes",   type=int,   default=3000)
    p.add_argument("--eval-every", type=int,   default=100)
    p.add_argument("--seed",       type=int,   default=42)
    p.add_argument("--resume",     type=str,   default=None)
    p.add_argument("--ckpt-dir",   type=str,   default="checkpoints")
    p.add_argument("--log-dir",    type=str,   default="logs")
    p.add_argument("--compare",    action="store_true")
    p.add_argument("--dt",         type=float, default=0.4)
    p.add_argument("--max-thrust", type=float, default=0.003)
    return p.parse_args()


def main():
    args = parse_args()
    np.random.seed(args.seed)

    cfg = RPODConfig(dt=args.dt, max_thrust=args.max_thrust)
    os.makedirs(args.ckpt_dir, exist_ok=True)
    os.makedirs(args.log_dir,  exist_ok=True)

    if args.compare:
        run_comparison(cfg)
        return

    if args.algo in ("ppo", "both"):
        train_ppo(
            n_episodes=args.episodes,
            eval_every=args.eval_every,
            ckpt_dir=args.ckpt_dir,
            resume=args.resume if args.algo == "ppo" else None,
            log_dir=args.log_dir,
            cfg=cfg,
            seed=args.seed,
        )

    if args.algo in ("dqn", "both"):
        train_dqn(
            n_episodes=args.episodes,
            eval_every=args.eval_every,
            ckpt_dir=args.ckpt_dir,
            resume=args.resume if args.algo == "dqn" else None,
            log_dir=args.log_dir,
            cfg=cfg,
            seed=args.seed,
        )


if __name__ == "__main__":
    main()
