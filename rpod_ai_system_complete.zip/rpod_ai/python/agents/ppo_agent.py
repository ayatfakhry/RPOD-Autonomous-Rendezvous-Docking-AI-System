"""
ppo_agent.py — Proximal Policy Optimization Agent for RPOD
===========================================================
Implements PPO-Clip with:
  • Shared actor-critic backbone with separate heads
  • Generalised Advantage Estimation (GAE-λ)
  • Adaptive KL penalty fallback
  • Entropy regularisation for exploration
  • Gradient clipping and value loss clipping

References:
  Schulman et al. (2017). Proximal Policy Optimization Algorithms.
    arXiv:1707.06347
  Schulman et al. (2016). High-Dimensional Continuous Control Using
    Generalised Advantage Estimation. ICLR 2016.
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal
import torch.optim as optim
from typing import List, Dict, Tuple, Optional, NamedTuple
from collections import deque
import os
import logging

logger = logging.getLogger(__name__)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# ── Neural Networks ───────────────────────────────────────────────────────────

class ActorCriticNetwork(nn.Module):
    """
    Shared-encoder Actor-Critic network for continuous thrust control.

    Actor head:   outputs (mean, log_std) of Gaussian policy π(a|s)
    Critic head:  outputs scalar state value V(s)

    Architecture: LayerNorm + ELU for stable training with sparse rewards.
    """

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        hidden: List[int] = None,
        log_std_init: float = -1.5,
        log_std_min: float  = -4.0,
        log_std_max: float  =  0.5,
    ):
        super().__init__()
        hidden = hidden or [256, 256, 128]
        self.log_std_min = log_std_min
        self.log_std_max = log_std_max

        # ── Shared backbone ───────────────────────────────────────────────
        layers, in_d = [], obs_dim
        for h in hidden:
            layers += [
                nn.Linear(in_d, h),
                nn.LayerNorm(h),
                nn.ELU(),
            ]
            in_d = h
        self.backbone = nn.Sequential(*layers)

        # ── Actor head ────────────────────────────────────────────────────
        self.actor_mean = nn.Linear(in_d, action_dim)
        self.actor_log_std = nn.Parameter(
            torch.ones(action_dim) * log_std_init
        )

        # ── Critic head ───────────────────────────────────────────────────
        self.critic = nn.Sequential(
            nn.Linear(in_d, 64),
            nn.ELU(),
            nn.Linear(64, 1),
        )

        # Orthogonal initialisation (better for RL)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.orthogonal_(m.weight, gain=np.sqrt(2))
                nn.init.zeros_(m.bias)
        nn.init.orthogonal_(self.actor_mean.weight, gain=0.01)
        nn.init.zeros_(self.actor_mean.bias)

    def forward(self, obs: torch.Tensor) -> Tuple[Normal, torch.Tensor]:
        features = self.backbone(obs)
        mean     = self.actor_mean(features)
        log_std  = self.actor_log_std.expand_as(mean).clamp(
            self.log_std_min, self.log_std_max
        )
        dist  = Normal(mean, log_std.exp())
        value = self.critic(features).squeeze(-1)
        return dist, value

    def get_value(self, obs: torch.Tensor) -> torch.Tensor:
        features = self.backbone(obs)
        return self.critic(features).squeeze(-1)

    def evaluate_actions(
        self, obs: torch.Tensor, actions: torch.Tensor
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Returns log_probs, entropy, values for given (obs, action) pairs."""
        dist, values = self.forward(obs)
        log_probs = dist.log_prob(actions).sum(dim=-1)
        entropy   = dist.entropy().sum(dim=-1)
        return log_probs, entropy, values


# ── Rollout Buffer ────────────────────────────────────────────────────────────

class RolloutBatch(NamedTuple):
    obs:         torch.Tensor
    actions:     torch.Tensor
    log_probs:   torch.Tensor
    advantages:  torch.Tensor
    returns:     torch.Tensor
    values:      torch.Tensor


class RolloutBuffer:
    """
    Fixed-size on-policy rollout storage.
    Supports GAE-λ advantage estimation.
    """
    def __init__(self, size: int, obs_dim: int, action_dim: int, gamma: float, gae_lambda: float):
        self.size       = size
        self.gamma      = gamma
        self.gae_lambda = gae_lambda
        self._pos = 0
        self._full = False

        self.obs      = np.zeros((size, obs_dim),    dtype=np.float32)
        self.actions  = np.zeros((size, action_dim), dtype=np.float32)
        self.rewards  = np.zeros(size,               dtype=np.float32)
        self.dones    = np.zeros(size,               dtype=np.float32)
        self.values   = np.zeros(size,               dtype=np.float32)
        self.log_probs= np.zeros(size,               dtype=np.float32)
        self.advantages = np.zeros(size,             dtype=np.float32)
        self.returns    = np.zeros(size,             dtype=np.float32)

    def push(self, obs, action, reward, done, value, log_prob):
        self.obs[self._pos]       = obs
        self.actions[self._pos]   = action
        self.rewards[self._pos]   = reward
        self.dones[self._pos]     = done
        self.values[self._pos]    = value
        self.log_probs[self._pos] = log_prob
        self._pos  = (self._pos + 1) % self.size
        self._full = self._full or (self._pos == 0)

    def compute_returns_and_advantages(self, last_value: float):
        """GAE-λ advantage estimation."""
        gae  = 0.0
        last_val = last_value
        for t in reversed(range(self.size)):
            mask   = 1.0 - self.dones[t]
            delta  = self.rewards[t] + self.gamma * last_val * mask - self.values[t]
            gae    = delta + self.gamma * self.gae_lambda * mask * gae
            self.advantages[t] = gae
            self.returns[t]    = gae + self.values[t]
            last_val = self.values[t]

        # Normalise advantages
        adv = self.advantages
        self.advantages = (adv - adv.mean()) / (adv.std() + 1e-8)

    def get_batches(self, mini_batch_size: int):
        """Yield shuffled mini-batches."""
        n = self.size
        indices = np.random.permutation(n)
        for start in range(0, n, mini_batch_size):
            idx = indices[start:start + mini_batch_size]
            yield RolloutBatch(
                obs        = torch.FloatTensor(self.obs[idx]).to(DEVICE),
                actions    = torch.FloatTensor(self.actions[idx]).to(DEVICE),
                log_probs  = torch.FloatTensor(self.log_probs[idx]).to(DEVICE),
                advantages = torch.FloatTensor(self.advantages[idx]).to(DEVICE),
                returns    = torch.FloatTensor(self.returns[idx]).to(DEVICE),
                values     = torch.FloatTensor(self.values[idx]).to(DEVICE),
            )

    def is_full(self) -> bool:
        return self._full or self._pos == 0

    def reset(self):
        self._pos  = 0
        self._full = False


# ── PPO Agent ─────────────────────────────────────────────────────────────────

class PPOAgent:
    """
    Proximal Policy Optimisation (PPO-Clip) Agent.

    Implements continuous thrust control with:
      • Clipped surrogate objective: min(r·A, clip(r, 1−ε, 1+ε)·A)
      • Value function loss with optional clipping
      • Entropy bonus: −β·H[π(·|s)]
      • Adaptive KL penalty fallback
      • GAE-λ advantage estimation
      • Cosine LR annealing

    Args:
        obs_dim       : observation space dimension
        action_dim    : thrust action dimension (3 for [ax, ay, az])
        max_thrust    : physical thrust limit [m/s²]
        rollout_size  : steps per policy update
        n_epochs      : optimisation epochs per rollout
        mini_batch    : mini-batch size
        lr            : initial learning rate
        gamma         : discount factor
        gae_lambda    : GAE λ parameter
        clip_eps      : PPO clipping ratio ε
        value_coef    : critic loss coefficient
        entropy_coef  : entropy bonus β
        max_grad_norm : gradient clipping threshold

    Usage:
        agent = PPOAgent(obs_dim=18, action_dim=3)
        action, log_prob, value = agent.act(obs)
        agent.store(obs, action, reward, done, value, log_prob)
        if agent.buffer.is_full():
            metrics = agent.update(last_value)
    """

    def __init__(
        self,
        obs_dim: int = 18,
        action_dim: int = 3,
        max_thrust: float = 0.003,
        rollout_size: int = 2048,
        n_epochs: int = 10,
        mini_batch: int = 256,
        lr: float = 3e-4,
        gamma: float = 0.995,
        gae_lambda: float = 0.97,
        clip_eps: float = 0.2,
        value_coef: float = 0.5,
        entropy_coef: float = 0.005,
        max_grad_norm: float = 0.5,
        target_kl: float = 0.015,
        hidden: Optional[List[int]] = None,
    ):
        self.obs_dim      = obs_dim
        self.action_dim   = action_dim
        self.max_thrust   = max_thrust
        self.rollout_size = rollout_size
        self.n_epochs     = n_epochs
        self.mini_batch   = mini_batch
        self.clip_eps     = clip_eps
        self.value_coef   = value_coef
        self.entropy_coef = entropy_coef
        self.max_grad_norm= max_grad_norm
        self.target_kl    = target_kl
        self._update_count = 0
        self._episode      = 0

        # Network
        self.ac_net = ActorCriticNetwork(
            obs_dim, action_dim, hidden or [256, 256, 128]
        ).to(DEVICE)

        # Optimiser
        self.optimizer = optim.Adam(self.ac_net.parameters(), lr=lr, eps=1e-5)
        self.scheduler = optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=1_000_000
        )

        # Rollout buffer
        self.buffer = RolloutBuffer(rollout_size, obs_dim, action_dim, gamma, gae_lambda)

        # Tracking
        self.losses: deque = deque(maxlen=100)
        self.policy_losses: deque = deque(maxlen=100)
        self.value_losses: deque  = deque(maxlen=100)
        self.entropies: deque     = deque(maxlen=100)
        self.kl_divs: deque       = deque(maxlen=100)
        self.clip_fractions: deque= deque(maxlen=100)

        logger.info(
            f"PPO Agent initialised | obs={obs_dim} | action={action_dim} | "
            f"params={sum(p.numel() for p in self.ac_net.parameters()):,} | device={DEVICE}"
        )

    # ── Public API ────────────────────────────────────────────────────────────

    @torch.no_grad()
    def act(
        self, obs: np.ndarray, deterministic: bool = False
    ) -> Tuple[np.ndarray, float, float]:
        """
        Sample action from policy.
        Returns: (action [m/s²], log_prob, value_estimate)
        """
        obs_t = torch.FloatTensor(obs).unsqueeze(0).to(DEVICE)
        dist, value = self.ac_net(obs_t)

        if deterministic:
            action = dist.mean
        else:
            action = dist.sample()

        # Squash to thrust limits (tanh mapping)
        action_squashed = torch.tanh(action) * self.max_thrust
        log_prob = (
            dist.log_prob(action).sum(dim=-1)
            - torch.log(1 - action_squashed.pow(2) + 1e-6).sum(dim=-1)
        )

        return (
            action_squashed.squeeze(0).cpu().numpy(),
            float(log_prob.item()),
            float(value.item()),
        )

    def store(self, obs, action, reward, done, value, log_prob):
        """Store one step transition in the rollout buffer."""
        self.buffer.push(obs, action / self.max_thrust, reward, done, value, log_prob)

    def update(self, last_value: float) -> Dict[str, float]:
        """
        Perform PPO update over n_epochs of mini-batch gradient steps.
        Returns dict of training metrics.
        """
        self.buffer.compute_returns_and_advantages(last_value)
        self._update_count += 1

        all_policy_loss   = []
        all_value_loss    = []
        all_entropy       = []
        all_kl            = []
        all_clip_fraction = []

        for epoch in range(self.n_epochs):
            for batch in self.buffer.get_batches(self.mini_batch):
                # Evaluate current policy on stored transitions
                log_probs, entropy, values = self.ac_net.evaluate_actions(
                    batch.obs, batch.actions * self.max_thrust
                )

                # ── Policy loss (PPO-Clip) ────────────────────────────────
                log_ratio   = log_probs - batch.log_probs
                ratio       = log_ratio.exp()
                clipped     = torch.clamp(ratio, 1 - self.clip_eps, 1 + self.clip_eps)
                policy_loss = -torch.min(
                    ratio * batch.advantages,
                    clipped * batch.advantages,
                ).mean()

                # ── Value loss ────────────────────────────────────────────
                # With value clipping for stability
                v_pred_clipped = batch.values + (values - batch.values).clamp(
                    -self.clip_eps, self.clip_eps
                )
                value_loss = 0.5 * torch.max(
                    F.mse_loss(values, batch.returns),
                    F.mse_loss(v_pred_clipped, batch.returns),
                )

                # ── Entropy bonus ─────────────────────────────────────────
                entropy_loss = -entropy.mean()

                # ── Total loss ────────────────────────────────────────────
                loss = (
                    policy_loss
                    + self.value_coef * value_loss
                    + self.entropy_coef * entropy_loss
                )

                # ── Optimise ──────────────────────────────────────────────
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(
                    self.ac_net.parameters(), self.max_grad_norm
                )
                self.optimizer.step()

                # ── Diagnostics ───────────────────────────────────────────
                with torch.no_grad():
                    approx_kl     = ((ratio - 1) - log_ratio).mean().item()
                    clip_fraction = ((ratio - 1).abs() > self.clip_eps).float().mean().item()

                all_policy_loss.append(policy_loss.item())
                all_value_loss.append(value_loss.item())
                all_entropy.append(-entropy_loss.item())
                all_kl.append(approx_kl)
                all_clip_fraction.append(clip_fraction)

                # Early stopping on KL divergence
                if approx_kl > 1.5 * self.target_kl:
                    logger.debug(f"Early stop at epoch {epoch} — KL={approx_kl:.4f}")
                    break

        self.scheduler.step()
        self.buffer.reset()

        metrics = {
            "policy_loss":    float(np.mean(all_policy_loss)),
            "value_loss":     float(np.mean(all_value_loss)),
            "entropy":        float(np.mean(all_entropy)),
            "approx_kl":      float(np.mean(all_kl)),
            "clip_fraction":  float(np.mean(all_clip_fraction)),
            "lr":             self.scheduler.get_last_lr()[0],
            "update_count":   self._update_count,
        }
        for k, v in metrics.items():
            if k in ("policy_loss",):  self.policy_losses.append(v)
            if k in ("value_loss",):   self.value_losses.append(v)
            if k in ("entropy",):      self.entropies.append(v)
            if k in ("approx_kl",):    self.kl_divs.append(v)
            if k in ("clip_fraction",):self.clip_fractions.append(v)

        return metrics

    def end_episode(self):
        self._episode += 1

    def save(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            "ac_net":     self.ac_net.state_dict(),
            "optimizer":  self.optimizer.state_dict(),
            "update_count": self._update_count,
            "episode":    self._episode,
        }, path)
        logger.info(f"PPO checkpoint saved → {path}")

    def load(self, path: str):
        ckpt = torch.load(path, map_location=DEVICE)
        self.ac_net.load_state_dict(ckpt["ac_net"])
        self.optimizer.load_state_dict(ckpt["optimizer"])
        self._update_count = ckpt.get("update_count", 0)
        self._episode      = ckpt.get("episode", 0)
        logger.info(f"PPO checkpoint loaded ← {path} (update {self._update_count})")

    @property
    def mean_policy_loss(self) -> float:
        return float(np.mean(list(self.policy_losses))) if self.policy_losses else 0.0

    @property
    def mean_entropy(self) -> float:
        return float(np.mean(list(self.entropies))) if self.entropies else 0.0
